

DDL audit stage
---------------
  create table audit_stage_pcm_cards_dev.PCM_CARDS_STAGE_AUDIT (
  DATASET_NAME STRING,
  TABLE_NAME STRING,
  AUDIT_TIME TIMESTAMP,
  total_records_count int64,
  AUDITED_BY STRING)
  
   insert into cdeb12.PCM_CARDS_STAGE_AUDIT
  select "cdeb12" as DATASET_NAME,
  "PCM_CARDS_STAGE_AUDIT" as table_name,
  current_timestamp() as AUDIT_TIME,
  count(*) as total_records_count,
  "ramesh" as AUDITED_BY
  from cdeb12.customers_stg;
  
  
  
  
DDL audit_history
--------------
create OR REPLACE table gcp-bhanu.audit_hist_pcm_dev.PCM_CARDS_HIST_AUDIT (
  DATASET_NAME STRING,
  TABLE_NAME STRING,
  AUDIT_TIME TIMESTAMP,
  total_records_count int64,
   AUDITED_BY STRING)
  

  
DML audit_stage_insert
------------------
 insert into AUDIT_STAGE.PCM_CARDS_STAGE_AUDIT 
select
  'AUDIT_STAGE' as  DATASET_NAME ,
  'PCM_CARDS_STAGE_AUDIT' as  TABLE_NAME ,
  current_timestamp as AUDIT_TIME ,
  count(*) as total_records_count ,
   'lakshmi' AUDITED_BY 
   from GCP_DATA_STAGE.PCM_CARDS
   
DML audit_history_insert
--------------------
    insert into AUDIT_HISTORY.PCM_CARDS_HIST_AUDIT 
select
  'AUDIT_HISTORY' as  DATASET_NAME ,
  'PCM_CARDS_HIST_AUDIT' as  TABLE_NAME ,
  current_timestamp as AUDIT_TIME ,
  count(*) as total_records_count ,
  'lakshmi' AUDITED_BY 
  from `GCP_DATA_HISTORY.PCM_CARDS_HISTORY`